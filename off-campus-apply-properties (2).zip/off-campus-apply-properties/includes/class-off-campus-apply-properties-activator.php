<?php

/**
 * Fired during plugin activation
 *
 * @link       #
 * @since      1.0.0
 *
 * @package    Off_Campus_Apply_Properties
 * @subpackage Off_Campus_Apply_Properties/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Off_Campus_Apply_Properties
 * @subpackage Off_Campus_Apply_Properties/includes
 * @author     # <#>
 */
class Off_Campus_Apply_Properties_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
