=== Off CAMPUS APPLY ===
Contributors: mohammad karrar
Donate link: #
Tags: listing, property manager
Requires at least: 3.0.1
Tested up to: 5.7.2
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Here is a short description of the plugin.  This should be no more than 150 characters.  No markup here.

== Description ==

Custom plugin develop for offcampusapply.com

== Changelog ==

= 1.0 =
* initial