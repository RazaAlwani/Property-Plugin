<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              #
 * @since             1.0.0
 * @package           Off_Campus_Apply_Properties
 *
 * @wordpress-plugin
 * Plugin Name:       Off Campus Apply Properties 
 * Plugin URI:        https://offcampusapply.com/
 * Description:       Property management plugin for offcampusapply.com
 * Version:           1.0.0
 * Author:            Mohammad Karrar
 * Author URI:        #
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       off-campus-apply-properties
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'OFF_CAMPUS_APPLY_PROPERTIES_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-off-campus-apply-properties-activator.php
 */
function activate_off_campus_apply_properties() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-off-campus-apply-properties-activator.php';
	Off_Campus_Apply_Properties_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-off-campus-apply-properties-deactivator.php
 */
function deactivate_off_campus_apply_properties() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-off-campus-apply-properties-deactivator.php';
	Off_Campus_Apply_Properties_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_off_campus_apply_properties' );
register_deactivation_hook( __FILE__, 'deactivate_off_campus_apply_properties' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-off-campus-apply-properties.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_off_campus_apply_properties() {

	$plugin = new Off_Campus_Apply_Properties();
	$plugin->run();

}
run_off_campus_apply_properties();
