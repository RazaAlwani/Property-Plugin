<?php

function get_filtered_form_data( $user_email ){

	global $wpdb;
	$table_name = $wpdb->prefix . 'db7_forms';
	$form_data = $wpdb->get_results( "SELECT * FROM {$table_name} ORDER BY form_id DESC" );
	foreach ( $form_data as $key => $form ) {
		$data = unserialize(  $form->form_value ); // unserialize form data 
		// check if current user have submitted data
	
		if ( $data['user-email'] === $user_email ) {
			$filter = array(
				'user_id' 		=> get_current_user_id(),
				'user_email' 	=> $data['user-email'],
				'amenities' 	=> $data['amenities'],
				'bedrooms' 		=> $data['bedrooms'][0],
				'budget_from' 		=> $data['text-840'],
				'budget_to' 		=> $data['text-841'],
				'rating' 		=> $data['rating'][0],
			);
			break;
		}
	}
	return $filter;
}

function convert_num_to_text( $number ) {

	$number_text = array( 
		'One' 		=> 1,
		'Two' 		=> 2,
		'Three' 	=> 3,
		'Four' 		=> 4,
		'Five' 		=> 5,
		'Six' 		=> 6,
		'Seven' 	=> 7,
		'Eight' 	=> 8,
	);

	if ( array_search( $number, $number_text) !== false ) {
		return array_search( $number, $number_text);
	}
}