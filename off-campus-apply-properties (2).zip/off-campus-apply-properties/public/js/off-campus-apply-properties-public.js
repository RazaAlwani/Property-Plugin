(function( $ ) {
	'use strict';

	$( document ).ready( function() {
		
		/* SUBMIT WPCF7 FORM AND REDIRECT TO FILTERERED PROPERTIES LISTING PAGE */
		$( document ).on( 'click', '.wpcf7-submit', function() {
			  window.location.href = "/filtered-properties";
		});

		/* HIDE CLICKED PROPERTY ON LISTING PAGE */
		$( document ).on( 'click', '.remove_cpt_property_from_listing', function(){
			var items = 0;
			$('.remove_cpt_property_from_listing').each( function() {
				items++;
			});

			if ( items > 1 ) {
				$( this ).parent().parent().closest('.listing-flex-item').slideUp();
				// console.log( 10 );

			}
		});
		
		/* SEND EMAIL TO ALL VENDOR AJAX CALL */
		$( document ).on( 'click', '.btn_apply_to_all', function(){ 
			var applicant_id = $( this ).attr( 'data-applicant-id' );
			var amenities = $( this ).attr( 'data-amenities' );
			var bedrooms = $( this ).attr( 'data-bedrooms' );
			var budget = $( this ).attr( 'data-budget' );
			var budget_from = $( this ).attr( 'data-budget-from' );
			var budget_to = $( this ).attr( 'data-budget-to' );

			$.ajax({
        		url: Off_Campus_ApplY_VARS.ajax_url,
        		data:{
        			action: 'offcampusapply_send_email_to_all_vendor',
        			applicant_id: applicant_id,
        			amenities: amenities,
        			bedrooms: bedrooms,
        			budget: budget,
        		},
        		method: 'POST',
        		success: function( result ) {
        			if ( result.success == true ){
        			    
        				if ( result.data.length > 50 ) {
        				    // console.log( result.data );
        					window.location.href = result.data;
        					return;
        				}
 
        				var msg = $( '.success_email_msg' );
        				$( msg ).text( Off_Campus_ApplY_VARS.success_email_message );
		            	$( msg ).css( 'text-transform', 'none' );
		            	$( msg ).slideDown();
		            	$( msg ).delay( 2000 ).slideUp();

        			} else if ( result.success == false ) {
        				alert( Off_Campus_ApplY_VARS.error_message );
        			} 
        		}
        	});

		});

		/* SEND EMAIL TO VENDOR/SUBSCRIBER AJAX CALL */
		$( document ).on( 'click', '.btn_apply_to_property', function(){
			var applicant_id = $( this ).attr( 'data-applicant-id' );
			var vendor_id = $( this ).attr( 'data-vendor-id' );
			var amenities = $( this ).attr( 'data-amenities' );
			var bedrooms = $( this ).attr( 'data-bedrooms' );
			var budget_from = $( this ).attr( 'data-budget-from' );
			var budget_to = $( this ).attr( 'data-budget-to' );
			var property_id = $( this ).attr( 'data-property-id' );

// 			console.log( amenities, bedrooms, budget );
			$.ajax({
        		url: Off_Campus_ApplY_VARS.ajax_url,
        		data:{
        			action: 'offcampusapply_send_email_to_vendor',
        			applicant_id: applicant_id,
        			property_id: property_id,
        			vendor_id: vendor_id,
        			amenities: amenities,
        			bedrooms: bedrooms,
        			budget_from: budget_from,
        			budget_to: budget_to,
        		},
        		method: 'POST',
        		success: function( result ) {
        // 			console.log(result);
        			if ( result.success == true ){
        				console.log( result.data );
        				if ( result.data.length > 50 ) {
        				    
        					window.location.href = result.data;
        					return;
        				}
        				var msg = $( '.success_email_msg-' + property_id );
        				$( msg ).text( Off_Campus_ApplY_VARS.success_email_message );
		            	$( msg ).css( 'text-transform', 'none' );
		            	$( msg ).css( 'color', 'green' );
		            	$( msg ).css( 'margin-top', '15px' );
		            	$( msg ).slideDown();
		            	$( msg ).delay( 2000 ).slideUp();
        			} else {
        				alert( Off_Campus_ApplY_VARS.error_message );
        			}
        		}
        	});
		});
    	
		/* SWITCH TO ADD PROPERTIES TAB */
    	$( document ).on( 'click', '#cpt_properties_add', function(){
    		$( this ).addClass( 'active' );
    		$( '#cpt_properties_add_tab' ).slideDown();
    		$( '#cpt_properties_add_tab' ).show();
    		
    		$( '#cpt_properties_view_tab' ).slideUp();
    		$( '#cpt_properties_view_tab' ).hide();
    		$( '#cpt_properties_view' ).removeClass( 'active' );
    	});

		/* SWITCH TO VIEW PROPERTIES TAB */
    	$( document ).on( 'click', '#cpt_properties_view', function(){
    		$( this ).addClass( 'active' );
    		$( '#cpt_properties_view_tab' ).slideDown();
    		$( '#cpt_properties_view_tab' ).show();
    		
    		$( '#cpt_properties_add_tab' ).slideUp();
    		$( '#cpt_properties_add_tab' ).hide();
    		$( '#cpt_properties_add' ).removeClass( 'active' );
    	});

		/* MARK AMENITIES CHECK */
    	$( document ).on( 'change', '.cpt_properties_amenities', function() {
    		if ( $( this ).attr( 'checked' ) == 'checked' ){
    			$( this ).removeAttr( 'checked' );
    		} else {
    			$( this ).attr( 'checked', 'checked' );
    		}
    	});

		/* REMOVE PROPERTY FOR VENDOR LISTING [ TRASH ] AJAX CALL */
    	$( document ).on( 'click', '#remove_cpt_property', function(){
    		var property_id = $( this ).attr( 'data-id' );
	    	$.ajax({
        		url: Off_Campus_ApplY_VARS.ajax_url,
        		data:{
        			action: 'offcampusapply_remove_company_property',
        			property_id: property_id,
        		},
        		method: 'POST',
        		success: function( result ) {
        			if ( result.success == true ){
        				alert( 'Are you sure you want to remove this property ?' );
		            	location.reload();
        			} else {
        				alert( Off_Campus_ApplY_VARS.error_message );
        			}
        		}
        	});
    	});

		/* ADD COMPANY LOGO TO DB/WORDPRESS MEDIA AJAX CALL */
    	$( document ).on( 'change', '#cpt_properties_logo', function(){

    	});

    	function upload_media( pid ){
    		var file_obj = $('#cpt_properties_logo')[0].files[0];
	        var form_data = new FormData();
            form_data.append('file', file_obj);
            form_data.append('post_id', pid );
	        form_data.append('action', 'offcampusapply_company_logo_upload');
	        $.ajax({
	            url: Off_Campus_ApplY_VARS.ajax_url,
	            type: 'POST',
	            contentType: false,
	            processData: false,
	            data: form_data,
	            success: function (response) {
	            }
	        });
    	}

		/* ADD NEW PROPERTY FOR VENDOR AJAX CALL */
    	$( document ).on( 'click', '#add_new_cpt_property', function(){
    		var property_name = $( '#cpt_properties_company' ).val();
    		var _location = $( '#cpt_properties_location' ).val();
    		var website = $( '#cpt_properties_website' ).val();
    		var email = $( '#cpt_properties_email' ).val();
    		var logo = $( '#cpt_properties_logo' ).val();
    		var amenities = [];
    		var rooms = [];
    		var rents = [];

    		$( '.cpt_properties_amenities' ).each( function(){
                if ( $( this ).attr( 'checked' ) == 'checked' )
                	amenities.push( $(this).val() );
            });

    		$( '.cpt_properties_rooms' ).each( function(){
            	var value = $( this ).val();
            	var room_size = $( this ).attr('data-id');
            	if ( value !== '' ) {
            		rooms.push( room_size );
            		rents.push( value );
            	}
            });

    		// Validation check	
            if ( property_name == '' || _location == '' || amenities.length == 0 || rooms.length == 0 
            	|| email == '' || website == '' || logo == '') {
            	$( '#error_msg' ).text( Off_Campus_ApplY_VARS.validation_message );
            	$( '#error_msg' ).css( 'text-transform', 'none' );
            	$( '#error_msg' ).slideDown();
            	$( '#error_msg' ).delay( 2000 ).slideUp();
            } else {
            	$.ajax({
            		url: Off_Campus_ApplY_VARS.ajax_url,
            		data:{
            			action: 'offcampusapply_save_company_property',
            			property_name: property_name,
            			location: _location,
            			amenities: amenities,
            			rooms: rooms,
            			rents: rents,
            			website: website,
            			email: email,
            			logo: logo
            		},
            		method: 'POST',
            		success: function( result ) {
            // 			console.log( result );
            			if ( result.success ){
            				$( '#success_msg' ).text( Off_Campus_ApplY_VARS.success_message );
			            	$( '#success_msg' ).css( 'text-transform', 'none' );
			            	$( '#success_msg' ).slideDown();
			            	$( '#success_msg' ).delay( 2000 ).slideUp();
			            	upload_media( result.data );
			            	location.reload();
            			} else {
            				$( '#error_msg' ).text( Off_Campus_ApplY_VARS.error_message );
			            	$( '#error_msg' ).css( 'text-transform', 'none' );
			            	$( '#error_msg' ).slideDown();
			            	$( '#error_msg' ).delay( 2000 ).slideUp();	
            			}
            		}
            	});
            }
    	});
    	
    	
        // SHOW ONLY 4 PROPERITES ON PAGE LOAD
        $( '.listing-flex-item' ).slice(0, 4).show(); 
        // LOAD MORE PROPERTIES ON CLICK EVENT
        $( document ).on( 'click', '#cpt_load_more_button', function( e ) {
            e.preventDefault();
            $( '.listing-flex-item:hidden' ).slice(0, 4).slideDown();
            if ( $( '.listing-flex-item:hidden' ).length === 0 ) {
                $( this ).fadeOut( 'slow' );
            }
        });
	});

})( jQuery );