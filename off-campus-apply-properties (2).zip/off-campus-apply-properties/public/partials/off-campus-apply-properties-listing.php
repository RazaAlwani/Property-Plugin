
<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<?php
	
	$user_id = get_current_user_id();
	$user_info = get_userdata( $user_id );
	$user_email = $user_info->user_email;

	$filter = array();
	$filter = get_filtered_form_data( $user_email );
    //echo "<pre>";
    //print_r($filter);
    //die();
    //die(print_r($filter));
	$converted_form_rating = intval( strlen( $filter['rating'] ) / 3 );
    // echo intval(strlen($filter['rating']) / 3);
    // die();
	
	$paged = ( get_query_var('paged') ) ? get_query_var( 'paged' ) : 1;
   	$postsPerPage = 4;
   	$postOffset = $paged * $postsPerPage;
	
	$args = array(
		'post_type' 	=> 'property',
		'post_status' 	=> 'publish',
		'numberposts' 	=> -1,
// 		'offset' 		=> $postOffset - $postsPerPage,
		'orderby' 		=> 'cpt_properties_ratings',
		'order' 		=> 'DESC',
		'meta_query'	=> array(
//			'relation'		=> 'OR',
			array(
				'key'	  	=> 'cpt_properties_rooms',
				'value'	  	=> $filter['bedrooms'],
				'compare' 	=> 'LIKE',
			),
			array(
				'key'	  	=> 'cpt_properties_rents',
				'value'	  	=> $filter['budget_to'],
				'compare' 	=> '<=',
                'type' => 'numeric',
			),
			array(
				'key'	  	=> 'cpt_properties_amenities',
				'value'	  	=> $filter['amenities'],
				'compare' 	=> 'LIKE',
			),
			array(
				'key'	  	=> 'cpt_properties_ratings',
				'value'	  	=> $converted_form_rating,
				'compare' 	=> '>=',
			),
		),
	);

	$total = array(
		'post_type' 	=> 'property',
		'post_status' 	=> 'publish',
		'orderby' 		=> 'cpt_properties_ratings',
		'order' 		=> 'DESC',
		'meta_query'	=> array(
//			'relation'		=> 'OR',
			array(
				'key'	  	=> 'cpt_properties_rooms',
				'value'	  	=> $filter['bedrooms'],
				'compare' 	=> 'LIKE',
			),
			array(
				'key'	  	=> 'cpt_properties_rents',
				'value'	  	=> $filter['budget_to'],
				'compare' 	=> '<=',
      			'type' => 'numeric',
			), 
			array(
				'key'	  	=> 'cpt_properties_amenities',
				'value'	  	=> $filter['amenities'],
				'compare' 	=> 'LIKE',
			),
			array(
				'key'	  	=> 'cpt_properties_ratings',
				'value'	  	=> $converted_form_rating,
				'compare' 	=> '>=',
			),
		),
	);
	$properties = get_posts( $args );
	$number_off_properties = count( get_posts( $total ) );
    
    //echo "<pre>";
    //die(print_r($properties));

	if ( empty( $properties ) ) {
		echo '<p> Sorry no properties found. </p>'; 
		return false;
	}
?>

<div class="flex-container">
	
	<button 
		data-applicant-id="<?php echo $user_id; ?>"
		data-amenities="<?php echo implode(',',$filter['amenities']); ?>"
		data-bedrooms="<?php echo $filter['bedrooms']; ?>"
		data-budget="<?php echo $filter['budget']; ?>"
		class="btn_apply_to_all" id="btn_apply_to_all" style="display: none;">Apply for All</button>
	<p class="success_email_msg" style="float:right;"></p>
    <?php $index = 0; ?>
	<?php foreach ( $properties as $key => $property): ?>
		<?php
        $index++;
		$cpt_vendor_id = get_post_meta( $property->ID, 'cpt_properties_company', true );
		$cpt_properties_amenities = get_post_meta( $property->ID, 'cpt_properties_amenities', true );  
		$cpt_properties_rooms = get_post_meta( $property->ID, 'cpt_properties_rooms', true );
		$cpt_properties_rents = get_post_meta( $property->ID, 'cpt_properties_rents', true );
		$cpt_properties_email = get_post_meta( $property->ID, 'cpt_properties_email', true );
		$cpt_properties_website = get_post_meta( $property->ID, 'cpt_properties_website', true );
		$cpt_properties_ratings = get_post_meta( $property->ID, 'cpt_properties_ratings', true );
		
		if ( array_intersect( $filter['amenities'], $cpt_properties_amenities ) ){
			$combine_rooms_rents = array();
			foreach ( $cpt_properties_rooms as $key => $room ) {
				if ( $cpt_properties_rents[ $key ] != 0 ) {
					if ( $key < 2 )
						$combine_rooms_rents[ $key ] = $room . ' Bedroom: <span class="cpt_price">' . $cpt_properties_rents[ $key ] . ' $ </span>';
					else	
						$combine_rooms_rents[ $key ] = $room . ' Bedrooms: <span class="cpt_price">' . $cpt_properties_rents[ $key ] . '$ </span>';
				}
			}
			$y = implode( '<br />', $combine_rooms_rents );
		?>
		<div class="listing-flex-item">
			<div class="property-grid" style="position:relative;">
				<table cellspacing="10" cellpadding="10" border="0">
					<tr>
						<td width="25%">
							<div class="company-logo">
								<?php 
								if ( ! empty( get_post_thumbnail_id( $property->ID ) ) ){
									echo '<img src="'. get_the_post_thumbnail_url( $property->ID, 'thumbnail' ) .'" height="100" width="100">';
								} else {
									echo '<img src="https://offcampusapply.com/wp-content/uploads/2021/06/off-campus-logo.png" height="100" width="100">';
								}
								?>
							</div>	
						</td>
						<td width="50%">
							<div class="property-desc">
                            	<?php if($index == 1) { ?><p style="color: #F3A712; margin-bottom: .8rem;"><strong>Most Recommended</strong></p> <?php } ?>
								<p class="title"><?php echo get_the_title( $property->ID ); ?></p>
								<p class="location">
									<i class="e113-32 x-icon" aria-hidden="true" data-x-icon-l=""></i>
									<?php echo get_post_meta( $property->ID, 'cpt_properties_address', true ); ?>
								</p>
								<p>
									<span style="display: block; text-decoration: underline ;">Amenities </span>
									<span style="font-size:12px;"><?php echo implode( ', ', get_post_meta( $property->ID, 'cpt_properties_amenities', true ) ); ?></span>
								</p>
								<p>
									<?php //echo $y; ?>
								</p>
								<p class="success_email_msg-<?php echo $property->ID; ?>"></p>
							</div>			
						</td>
						<td width="25%">
							<!-- <h1 class="remove_cpt_property_from_listing">X</h1> -->
							<div class="cpt_ratings">
								<?php 
									for( $i = 0; $i < 5; $i++ ) {
										if ( $i < $cpt_properties_ratings ) {
											echo '<span class="fa fa-star checked"></span>';
										} else {
											echo '<span class="fa fa-star"></span>';
										}
									}

									if ( $cpt_properties_ratings < 1 ) {
										echo '<p> 0 Rating</p>';
									} else {
										echo '<p>'. $cpt_properties_ratings . ' Ratings </p>';
									}
								?>
							</div>
							<a id="btn_remove_from_list" class="remove_cpt_property_from_listing" 
								href="javascrip:;">Remove from list</a>
							<button 
									data-property-id="<?php echo $property->ID; ?>"
									data-vendor-id="<?php echo $cpt_vendor_id; ?>"
									data-applicant-id="<?php echo $user_id; ?>"
									data-amenities="<?php echo implode(',',$filter['amenities']); ?>"
									data-bedrooms="<?php echo $filter['bedrooms']; ?>"
									data-budget-from="<?php echo $filter['budget_from']; ?>"
									data-budget-to="<?php echo $filter['budget_to']; ?>"
									class="btn_apply_to_property" 
									id="btn_apply_to_property">One-Click Apply</button>
						</td>
					</tr>
				</table>
			</div>				
		</div>
	<?php } ?>
	<?php endforeach; ?>
	<div class="cpt_pagination">
		<?php $total_pages = ceil( $number_off_properties / $postsPerPage );?>
		<?php if ( $total_pages > 1 ){ ?>
			<button id="cpt_load_more_button" class="cpt_load_more_button" data-total="<?php echo $total_pages;?>" >Load more</button>
		<?php } ?>
	</div>
    
    
</div>

<div style="text-align: center;margin-top: 10px;">
	<a href="/my-account" id="" class="cpt_load_more_button" style="display: inline-block;text-align: center;padding-top: 6px;color: #FFF;">Back to Dashboard</a>
</div>
<!-- END OF LISTING PAGE -->