<?php 
	$rooms = array( 1,2,3,4,5,6,7,8 );
	$amenities = array( 
		__( 'Furniture', 'off-campus-apply-properties' ),
		__( 'All Utilities', 'off-campus-apply-properties' ), 
		__( 'Washer/Dryer', 'off-campus-apply-properties' ),
		__( 'Off-Street Parking', 'off-campus-apply-properties' ), 
		__( 'Snow Removal', 'off-campus-apply-properties' ),
		__( 'Pet-Friendly', 'off-campus-apply-properties' ),
		__( 'Gymnasium', 'off-campus-apply-properties' ), 
		__( 'Swimming Pool', 'off-campus-apply-properties' ),
	);
	
	
?>

<!-- Tab links - start -->
<ul class="vendor_dashboard_tabs">
	<li id="cpt_properties_add" class="active"> Add Properties </li>
	<li id="cpt_properties_view"> View Properties </li>
</ul>
<!-- Tab links - end -->

<!-- Add Properties tab - start  -->
<div id="cpt_properties_add_tab" class="flex-container">
	<div class="flex-item">
		<label>Property Name:</label>
		<input type="text" size="50" name="cpt_properties_company" id="cpt_properties_company" />
		<label>Location:</label>
		<input type="text" size="50" name="cpt_properties_location" id="cpt_properties_location" />
		<label>Email:</label>
		<input type="email" size="50" name="cpt_properties_email" id="cpt_properties_email" />
		<label>Website:</label>
		<input type="text" size="50" name="cpt_properties_website" id="cpt_properties_website" />
	
	</div>
	<div class="flex-item">
		<p>Rooms and Rents:</p>
			<?php 
				foreach ( $rooms as $key => $value ) {
					$key++;
					echo '<div class="cpt_properties_rooms_div">';
					echo '<label for="cpt_properties_rooms">'; 
					echo convert_num_to_text( $value ) . ' Bedrooms ';
					echo '<span class="rooms_rents_span"><input type="text" size="5" placeholder="$ 0" data-id="'.$key.'" name="cpt_properties_rooms[]" class="cpt_properties_rooms" style="margin-left:10px;" value=""></span>';
					echo '</label>';
					echo '</div>';
				}
			?>
	</div>
	<div class="flex-item">
		<p>Amenities:</p>
			<?php
				foreach ( $amenities as $key => $value ) {
					echo '<label for="cpt_properties_amenities">'; 
					echo '<input type="checkbox" style="width: 7%;" name="cpt_properties_amenities[]" class="cpt_properties_amenities" multiple="multiple" value="'. esc_attr( $value ) .'">';
					echo $value;		
					echo '</label>';
				}
			?>
		</select>
	</div>
	<div class="flex-item">
		<p> Company Picture/Logo </p>
		<form method="post" action="" enctype="multipart/form-data" id="upload_logo_form">
	        <div class="preview">
            	<img src="" id="img" width="100" height="100">
        	</div>
	        <div>
	            <input type="file" id="cpt_properties_logo" name="cpt_properties_logo" />
	            <input type="button" class="button" value="Upload" id="cpt_upload_image">
	        </div>
    	</form>
	</div>
	<div class="flex-item">
		<p id="error_msg"></p>
		<p id="success_msg"></p>
		<button id="add_new_cpt_property">Save</button>
	</div>
</div>
<!-- Add Properties tab - end  -->

<?php
	$author = get_current_user_id(); 
	$args = array( 
		'author' => $author, 
		'post_type' => 'property', 
		'post_status' => 'publish', 
	);
	$properties = get_posts( $args );
?>
<!-- View Properties tab - start  -->
<div id="cpt_properties_view_tab" class="flex-container">
	<?php foreach ($properties as $key => $property): ?>
	<?php
		$cpt_properties_amenities = get_post_meta( $property->ID, 'cpt_properties_amenities', true );  
		$cpt_properties_rooms = get_post_meta( $property->ID, 'cpt_properties_rooms', true );
		$cpt_properties_rents = get_post_meta( $property->ID, 'cpt_properties_rents', true );
		$combine_rooms_rents = array();

		foreach ( $cpt_properties_rooms as $key => $room ) {
			if ( $cpt_properties_rents[ $key ] != 0 ) {
				if ( $key < 2 )
					$combine_rooms_rents[ $key ] = $room . '-Bedroom: ' . $cpt_properties_rents[ $key ] . ' $';
				else	
					$combine_rooms_rents[ $key ] = $room . '-Bedrooms: ' . $cpt_properties_rents[ $key ] . '$ ';
			}
		}
		$x = implode( ', ', $cpt_properties_amenities );
		$y = implode( '<br />', $combine_rooms_rents );
	?>
	<div class="flex-item-properties-listing">
		<button id="remove_cpt_property" data-id="<?php echo $property->ID ?>"> Remove </button>
		<p style="font-size: 20px; margin-bottom: 5px;"> <?php echo get_the_title( $property->ID ); ?></p>
		<p style="font-size: 14px;"> <?php echo get_post_meta( $property->ID, 'cpt_properties_address', true ); ?> </p>
		<p>
			Amenities: <br />
			<span style="font-weight: normal;"><?php echo $x; ?></span>
		</p>
		<p>
			Rooms/Rent: <br />
			<span style="font-weight: normal;"> <?php echo $y; ?> </span>
		</p>
	</div>
	<?php endforeach ?>

	<?php if ( empty( $properties) ): ?>
		<p> <?php echo __( 'You have added 0 properties', 'off-campus-apply-properties' ); ?></p>
	<?php endif; ?>
</div>
<!-- View Properties tab - end  -->
