<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       #
 * @since      1.0.0
 *
 * @package    Off_Campus_Apply_Properties
 * @subpackage Off_Campus_Apply_Properties/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Off_Campus_Apply_Properties
 * @subpackage Off_Campus_Apply_Properties/public
 * @author     # <#>
 */
class Off_Campus_Apply_Properties_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/off-campus-apply-properties-public.css', array(), $this->version, 'all' );
	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/off-campus-apply-properties-public.js', array( 'jquery' ), $this->version, true );

		// localize data
		$data = array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'success_message' => __( 'Data saved', 'off-campus-apply-properties' ),
			'validation_message' => __( 'Please fill all the fields correctly', 'off-campus-apply-properties' ),
			'error_message' => __( 'Something went wrong !', 'off-campus-apply-properties' ),
			'success_email_message' => __( 'Your application is submitted', 'off-campus-apply-properties' ),
		);
		wp_localize_script( $this->plugin_name, 'Off_Campus_ApplY_VARS', $data );
	}

	public function user_registration_add_vendor_dashboard( $items ) {
		$user = wp_get_current_user();
		$temp = array();

		if ( in_array( 'vendor', (array) $user->roles ) ) {
			$temp['vendor-company-dashboard'] = 'Your Properties';
		}

		if ( in_array( 'customer', (array) $user->roles ) || in_array( 'administrator', (array) $user->roles ) ) {
			$temp['questions'] = 'Questions';
			$temp['filtered-properties'] = 'Results';
		}
		$temp = array_merge( $temp, $items );
		$p1 = array_splice($temp,0, 1);
		$p2 = array_splice($temp, 1, 1);
		$temp = array_merge($p2,$p1,$temp);

    	return $temp;
	}
 
	public function vendors_dashboard( $atts = array(), $content = '' ) {
		
		$user = wp_get_current_user();
		$roles = ( array ) $user->roles ;
		if (  ! in_array( 'vendor', (array) $roles ) ) {
			echo '<p> You are not allowed to access this page </p>';
			return false;
		}	
		ob_start();
		// load vendors dashboard template
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/partials/off-campus-apply-vendors-dashboard.php';
		return ob_get_clean();	
	}

	public function properties_listing( $atts = array(), $content = '' ) {
		ob_start();
		// load vendors dashboard template
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/partials/off-campus-apply-properties-listing.php';
		return ob_get_clean();	
	}

	public function register_shortcode() {
		add_shortcode( 'offcampusapply-vendor-dashboard', array( $this, 'vendors_dashboard' ) );
		add_shortcode( 'offcampusapply-properties-listing', array( $this, 'properties_listing' ) );
	}

	public function offcampusapply_remove_company_property_callback() {
		
		// if user is not logged in return
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( $success = false );
		}

		// if any data is missing send error
		if ( ! isset( $_POST['property_id'] ) ) {
			wp_send_json_error( $success = false );
		}

		$cpt_property = array(
		    'ID'            => $_POST['property_id'],
		    'post_status'   => 'trash',
		);

		if ( wp_update_post( $cpt_property ) > 0 ) {
			wp_send_json_success( $success = true );
		}		
	}

	public function offcampusapply_save_company_property_callback() {

		// if user is not logged in return
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( $success = false );
		}

		// if any data is missing send error
		if ( ! isset( $_POST['property_name'] ) || ! isset( $_POST['location'] )  || ! isset( $_POST['amenities'] ) || ! isset( $_POST['rooms'] ) || ! isset( $_POST['rents'] ) || 
			! isset( $_POST['website'] ) || ! isset( $_POST['email'] ) ) {

			wp_send_json_error( $success = false );
		}

		// Create cpt property object
		$cpt_property = array(
		  'post_type'     => 'property',
		  'post_title'    => wp_strip_all_tags( $_POST['property_name'] ),
		  'post_status'   => 'publish',
		  'post_author'   => get_current_user_id()
		);
		 
		// Insert the post into the database
		$cpt_property_id = wp_insert_post( $cpt_property );
		if ( isset ( $cpt_property_id ) ) {
			add_post_meta( $cpt_property_id, 'cpt_properties_company', get_current_user_id() );
			add_post_meta( $cpt_property_id, 'cpt_properties_address', $_POST['location'] );
			add_post_meta( $cpt_property_id, 'cpt_properties_amenities', $_POST['amenities'] );
			add_post_meta( $cpt_property_id, 'cpt_properties_rooms', $_POST['rooms'] );
			add_post_meta( $cpt_property_id, 'cpt_properties_rents', $_POST['rents'] );
			add_post_meta( $cpt_property_id, 'cpt_properties_website', $_POST['website'] );
			add_post_meta( $cpt_property_id, 'cpt_properties_email', $_POST['email'] );
			add_post_meta( $cpt_property_id, 'cpt_properties_logo', $_POST['logo'] );

			// added special key for comparing query
			add_post_meta( $cpt_property_id, 'cpt_properties_rents_string', implode(',', $_POST['rents'] ) );
			wp_send_json_success( $success = $cpt_property_id );
		}
		wp_send_json_error( $success = false );
	}

	public function offcampusapply_company_logo_upload_callback() {
		$post_id = isset( $_POST['post_id'] ) ? $_POST['post_id'] : 0; 
		if ( ! function_exists( 'wp_generate_attachment_metadata' ) ){
                require_once(ABSPATH . "wp-admin" . '/includes/image.php');
                require_once(ABSPATH . "wp-admin" . '/includes/file.php');
                require_once(ABSPATH . "wp-admin" . '/includes/media.php');
        }
		if ( $_FILES ) {
			foreach ($_FILES as $file => $array) {
			    if ($_FILES[$file]['error'] !== UPLOAD_ERR_OK) {
			        return "upload error : " . $_FILES[$file]['error'];
			    }
			    $attach_id = media_handle_upload( $file, $post_id );
			}   
		}
        if ( $attach_id > 0 ){
            //and if you want to set that image as Post  then use:
            update_post_meta( $post_id, '_thumbnail_id', $attach_id );
        }
	}

	public function offcampusapply_send_email_to_vendor_callback() {

		if ( ! is_user_logged_in() ){
			wp_send_json_error( $success = false );
		}

		if ( ! isset( $_POST['applicant_id'] ) || ! isset( $_POST['vendor_id'] ) ||
			! isset( $_POST['amenities'] ) || ! isset( $_POST['bedrooms'] ) || ! isset( $_POST['budget_to'] ) ){
			wp_send_json_error( $success = false );
		}
        
		$active_member = $this->check_active_memberships_for_user();
		if ( $active_member !== true ) {
			return wp_send_json_success( $active_member );
		}
        
		$applicant_id = $_POST['applicant_id'];
		$vendor_id = $_POST['vendor_id'];
		$vendor_company = get_user_meta( $vendor_id, 'user_registration_user_registration_company_name', true );

		$amenities = $_POST['amenities'];
		$bedrooms = $_POST['bedrooms'];
		$budget_from = $_POST['budget_from'];
		$budget_to = $_POST['budget_to'];
		$property_id = $_POST['property_id'];
        $property = get_post( $property_id );
        
        //echo "<pre>";
        //echo print_r( $_POST);
        //die('');


		$vendor_user = get_userdata( $vendor_id );
		$vendor_email = get_post_meta( $property_id, 'cpt_properties_email', true );
		$vendor_first_name = $vendor_user->first_name;

		$applicant_user = get_userdata( $applicant_id );
		$applicant_first_name = $applicant_user->first_name;
		$applicant_last_name = $applicant_user->last_name;
		$applicant_email = $applicant_user->user_email;
		$applicant_phone = get_user_meta( $applicant_id, 'user_registration_phone_number', true );
		
		$to = $vendor_email .', info@offcampusapply.com';
		$subject = 'New lead from OffCampusApply.com';
		$headers[] = 'Content-type: text/html';

     	$message = $this->get_vendor_email_template( $vendor_company, $vendor_first_name, $applicant_first_name, $applicant_last_name, $applicant_email, $applicant_phone, $amenities, $bedrooms, $budget_from, $budget_to, $property );

		$send_vendor_email = wp_mail( $to, $subject, $message, $headers, $attachments = null );
		$send_subscriber_email = $this->get_applicant_email_template( $applicant_email, $applicant_first_name );
		if ( $send_vendor_email && $send_subscriber_email ) {
			wp_send_json_success( $success = true );
		} else {
			wp_send_json_error( $success = false );
		}
		die();
	}

	private function check_active_user_user_role() {
		$user = wp_get_current_user();
		$user_role = '';
		if ( in_array( 'customer', (array) $user->roles ) ) {
			$user_role = 'customer';
		} elseif ( in_array( 'vendor', (array) $user->roles ) ) {
			$user_role = 'vendor';
		}
		return $user_role;
	}

	private function check_active_memberships_for_user() {

		// check logged in user role
		$check_user_role = $this->check_active_user_user_role();

		// get membership plans
		$plans = wc_memberships_get_membership_plans();

		// check if the member has an active membership for any plan
		foreach ( $plans as $plan ) {
			$active = wc_memberships_is_user_active_member( get_current_user_id(), $plan );
			if ( $active == true && $plan->slug !== 'registered-users' ){
				return $active;
			}
		}
	
		// if user has not active membership then send redirect url to membership page
		if ( $check_user_role == 'customer' ) {
			$redirect_url = get_site_url( get_current_blog_id() ) . '/product/offcampus-student-membership';
		} elseif ( $check_user_role == 'vendor' ) {
			$redirect_url = get_site_url( get_current_blog_id() ) . '/product/offcampus-company-membership';
		}
		
		return $redirect_url;
	}

	public function offcampusapply_send_email_to_all_vendor_callback() {

		if ( ! is_user_logged_in() ){
			wp_send_json_error( $success = false );
		}

		if ( ! isset( $_POST['applicant_id'] ) || ! isset( $_POST['amenities'] ) || ! isset( $_POST['bedrooms'] ) || ! isset( $_POST['budget'] ) ){
			wp_send_json_error( $success = false );
		}

		$active_member = $this->check_active_memberships_for_user();
		if ( $active_member !== true ) {
			return wp_send_json_success( $active_member );
		} 

		$applicant_id = $_POST['applicant_id'];
		$amenities = $_POST['amenities'];
		$bedrooms = $_POST['bedrooms'];
		$budget = $_POST['budget'];
		$property_id = $_POST['property_id'];
        $property = get_post( $property_id );

		$applicant_user = get_userdata( $applicant_id );
		$applicant_first_name = $applicant_user->first_name;
		$applicant_last_name = $applicant_user->last_name;
		$applicant_email = $applicant_user->user_email;
		$applicant_phone = get_user_meta( $applicant_id, 'user_registration_phone_number', true );
		$subject = 'New lead from OffCampusApply.com';
		$headers[] = 'Content-type: text/html';

		$vendors = get_users( array( 'role__in' => array( 'vendor' ) ) );
		if ( ! empty( $vendors ) ) {
			foreach( $vendors as $vendor ){
				$vendor_user = get_userdata( $vendor->ID );
				$vendor_first_name = $vendor_user->first_name;
				$vendor_company = get_user_meta( $vendor->ID, 'user_registration_user_registration_company_name', true );
	     		
				$to = $vendor_user->user_email;
	     		// message
	     		$message = $this->get_vendor_email_template( $vendor_company, $vendor_first_name, $applicant_first_name, $applicant_last_name, $applicant_email, $applicant_phone, $amenities, $bedrooms, $budget );
				
				$send_email = wp_mail( $to, $subject, $message, $headers, $attachments = null );
			}
		} else {
			wp_send_json_error( $success = false );
		}
		wp_send_json_success( $success = true );	
		die();
	}

	private function get_vendor_email_template( $vendor_company, $vendor_first_name, $applicant_first_name, $applicant_last_name, $applicant_email, $applicant_phone, $amenities, $bedrooms, $budget_from, $budget_to, $property ){

		$template = '';
        $template .= '<style>
                    /* Root */
                    html, body {
                        margin: 0;
                        font-family: -apple-system, BlinkMacSystemFont, Roboto, "Helvetica Neue", Arial, "Noto Sans",sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji" !important;
                        font-size: 16px;
                    }

                    .body-content {
                        margin: 0 auto;
                        max-width: 768px;
                        color: #231e1c;
                    }

                    .img-fluid { max-width: 100%; }

                    h1,h2,h3,h4,h5,h6 { margin-top: 0; margin-bottom: 8px; font-weight: 700; }
                    p { margin-top: 0; margin-bottom: 16px; }

                    hr { margin: 16px 0; border: none; border-top: 2px solid #f8a5a7 !important; }

                    ol { padding-left: 16px; }
                    ol li { margin-bottom: 8px; }

                    /* Utilities */
                    .d-inline          { display: inline !important; }
                    .d-inline-block    { display: inline-block !important; }

                    .mb-0              { margin-bottom: 0px !important; }
                    .mb-2              { margin-bottom: 8px !important; }
                    .mb-4              { margin-bottom: 16px !important; }
                    .mb-6              { margin-bottom: 32px !important; }
                    .mb-8              { margin-bottom: 48px !important; }

                    .ms-3              { margin-left: 12px !important; }

                    .me-3              { margin-right: 12px !important; }

                    .mx-auto           { margin-left: auto !important; margin-right: auto !important; }

                    .my-2              { margin-top: 8px !important; margin-bottom: 8px !important; }
                    .my-4              { margin-top: 16px !important; margin-bottom: 16px !important; }

                    .py-4              { padding-top: 16px !important; padding-bottom: 16px !important; }
                    .px-4              { padding-left: 4rem !important; padding-right: 4rem !important; }

                    .valign-middle     { vertical-align: middle !important; }

                    .py-2              { padding-top: 8px !important; padding-bottom: 8px !important; }
                    .py-4              { padding-top: 16px !important; padding-bottom: 16px !important; }
                    .py-6              { padding-top: 32px !important; padding-bottom: 32px !important; }

                    .obj-fit-contain   { object-fit: contain; }

                    /* Typography */
                    h1, .fs-1          { font-size: 40px !important; }
                    h2, .fs-2          { font-size: 32px !important; }
                    h3, .fs-3          { font-size: 28px !important; }
                    h4, .fs-4          { font-size: 24px !important; }
                    h5, .fs-5          { font-size: 14px !important; }
                    h6, .fs-6          { font-size: 18px !important; }
                    .small             { font-size: 12px !important; }

                    .text-white        { color: white !important; }
                    .text-black        { color: #231e1c !important; }
                    .text-blue        { color: #2b537c !important; }
                    

                    /* Custom */
                    .email-header {
                        padding: 16px 32px;
                        background-size: cover;
                        color: white;
                    }

                    .float-right {
                        float: right;
                    }

                    .bg-blue {
                        background-color: #355a81;
                    }

                    .bg-gray {
                        background-color: #e0e0e0;
                    }

                    .text-center {
                        text-align: center;
                    }

                    .p {
                        font-size: 1.4rem !important;
                    }
                    
                    .mw-800 {
                        max-width: 800px;
                        margin: 0 auto;
                    }
                </style>';
        $template .= '<div class="email-header mw-800">
                        <img src="https://offcampusapply.com/wp-content/uploads/2022/01/Group-1-1-1024x322-1.png" alt="" class="img-fluid mb-4" style="height: 150px;">

                        <h2 class="h2 text-black mb-0 float-right" style="margin-top: 3.5rem;">'. $property->post_title .'</h2>
                    </div>';
        $template .= '<div class="banner bg-blue py-6 text-center mw-800">
                        <h1 class="text-white">You have (1) New Lead</h1>
                        <p class="my-4"><img src="https://offcampusapply.com/wp-content/uploads/2022/01/Email-Icon.png" alt="" style="height: 120px;"></p>
                        <h4 class="text-white" style="font-weight: 400">Courtesy of OffCampusApply</h4>
                    </div>';
        $template .= '<div class="content px-4 py-6 mw-800" style="">
                        <p class="text-center" style="font-size: 1.3rem; font-weight: 500">A student has submitted an application with us and has indicated interest in your property. Please see their details and contact information below.</p>

                        <div style="">
                            <div class="py-4 mx-auto fs-4" style="max-width: 600px;">
                                <strong>Name:</strong> '. $applicant_first_name .' '. $applicant_last_name .' <br />
                                <strong>Phone:</strong> '. $applicant_phone .' <br />
                                <strong>E-Mail:</strong> '. $applicant_email .'<br />
                            </div>

                            <div class="bg-blue text-white mx-auto" style="margin-top: 1rem; max-width: 600px;"><h3 class="text-center" style="padding: .5rem 0;">Lead Details:</h3></div>

                            <div class="mx-auto fs-4" style="max-width: 600px;">
                                <strong>Property Name:</strong> '. $property->post_title .' <br />
                                <strong># of Bedrooms:</strong> '. $bedrooms .' <br />
                                <strong>Budget:</strong> $'. $budget_from .'-$'. $budget_to .' <br />
                                <strong>Desired Amenities:</strong> '. $amenities .'<br />
                            </div>
                        </div>

                        <p class="text-center" style="font-size: 1.3rem; font-weight: 500; margin-top: 2rem;">
                            We look forward to sending you more leads like this in the future.
                            Good luck and best regards! <br />
                            -OffCampusApply
                        </p>
                    </div>';
		

		$template .= '<div class="bg-gray text-center text-blue mw-800" style="padding: 2rem 0;">
						<p>
							<img src="https://offcampusapply.com/wp-content/uploads/2022/01/Group-1-1-1024x322-1.png" alt="" class="img-fluid mb-4" style="height: 80px;">
						</p>

						<p class="p">Copyright OffCampusApply. All Rights Reserved</p>
						
						<table class="mx-auto text-blue p">
							<tr>
								<td style="padding: .2rem 1rem; vertical-align:  middle;"><p class="text-center">211, E 43rd St., 7th Floor <br> #269, New York, NY 10007</p></td>
								<td style="padding: .2rem 1rem; vertical-align:  middle;border-left: 1px solid #355a81"><p class="text-center">1 (888) 250-4346</p></td>
							</tr>
						</table>

						<br>

						<p class="p">Questions about OffCampusApply? Click <a href="mailto: info@offcampusapply.com" style="color: #2b527c; text-decoration: none;"><strong>here</strong></a> to get in touch</p>
					</div>';

		return $template;
	}

	private function get_applicant_email_template( $applicant_email, $applicant_first_name ){

		$to = $applicant_email;
		$subject = 'Congratulations! Your applications have been sent.';
		$headers[] = 'Content-type: text/html';
		$template = '';
		$template .= '<h3> Hi '. $applicant_first_name .', </h3>';
		$template .= '<p> You have successfully completed your common-app with OffCampusApply.com and it has been sent to your chosen properties. </p>';
		$template .= '<p> Be on the lookout for calls and emails as they will be reaching out to you in the next day or two. They will walk you through the next steps to find the perfect apartment. </p>';
		$template .= '<p> Good luck and we will see you again next year! <br> -Team at OffCampusApply.com </p>';

		$message = $template;

		$send_email = wp_mail( $to, $subject, $message, $headers, $attachments = null );

		if ( $send_email ) {
			return true;
		}

		return false;		
	}
}