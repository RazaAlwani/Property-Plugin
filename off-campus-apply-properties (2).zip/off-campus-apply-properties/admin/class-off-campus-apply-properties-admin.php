<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       #
 * @since      1.0.0
 *
 * @package    Off_Campus_Apply_Properties
 * @subpackage Off_Campus_Apply_Properties/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Off_Campus_Apply_Properties
 * @subpackage Off_Campus_Apply_Properties/admin
 * @author     # <#>
 */
class Off_Campus_Apply_Properties_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/off-campus-apply-properties-admin.css', array(), $this->version, 'all' );

		// select2 css
		wp_enqueue_style( $this->plugin_name, 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css', array('jquery'), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/off-campus-apply-properties-admin.js', array( 'jquery' ), $this->version, false );

		// select2 js
		wp_enqueue_script( $this->plugin_name, 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', array( 'jquery' ), $this->version, false );
	}

	public function add_vendor_user_role_to_wp() {
		add_role(
		    'vendor',
		    __( 'Vendor', 'off-campus-apply-properties' ),
		    array(
		        'read'         => true,  // true allows this capability
		        'edit_posts'   => true,
		        'delete_posts' => true, // Use false to explicitly deny
		    )
		);
	}

	/**
	 * Register Post-type: Properties
	 *
	 * @since    1.0.0
	 */
	public function register_properties_fields_metabox() {
		add_meta_box( 
			'cpt-properties', 
			__( 'Property Details', 'off-campus-apply-properties' ), 
			array( $this, 'add_cpt_properties_fields' ), 
			'property', 
			'normal', 
			$priority = 'high', 
		);
	}

	/**
	 * Register Post-type: Properties
	 *
	 * @since    1.0.0
	 */
	public function register_properties_post_type() {
		$labels = array(
			'name'               => __( 'Properties', 'off-campus-apply-properties' ),
			'singular_name'      => __( 'Property', 'off-campus-apply-properties' ),
			'add_new'            => _x( 'Add New Property', 'off-campus-apply-properties', 'off-campus-apply-properties' ),
			'add_new_item'       => __( 'Add New Property', 'off-campus-apply-properties' ),
			'edit_item'          => __( 'Edit Property', 'off-campus-apply-properties' ),
			'new_item'           => __( 'New Property', 'off-campus-apply-properties' ),
			'view_item'          => __( 'View Property', 'off-campus-apply-properties' ),
			'search_items'       => __( 'Search Properties', 'off-campus-apply-properties' ),
			'not_found'          => __( 'No Properties found', 'off-campus-apply-properties' ),
			'not_found_in_trash' => __( 'No Properties found in Trash', 'off-campus-apply-properties' ),
			'parent_item_colon'  => __( 'Parent Singular Name:', 'off-campus-apply-properties' ),
			'menu_name'          => __( 'Properties', 'off-campus-apply-properties' ),
		);
	
		$args = array(
			'labels'              => $labels,
			'hierarchical'        => false,
			'description'         => 'Registered Vendors Properites',
			'taxonomies'          => array(),
			'public'              => true,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_admin_bar'   => true,
			'menu_position'       => null,
			'menu_icon'           => 'dashicons-admin-home',
			'show_in_nav_menus'   => false,
			'publicly_queryable'  => true,
			'exclude_from_search' => false,
			'has_archive'         => true,
			'query_var'           => true,
			'can_export'          => true,
			'rewrite'             => true,
			'capability_type'     => 'post',
			'supports'            => array(
				'title',
				// 'editor',
				'author',
				'thumbnail',
				'custom-fields',
			),
		);
		
		register_post_type( 'property', $args );
	}

	public function add_cpt_properties_fields( $post ) {
		wp_nonce_field( 'cpt_properties_save_meta_box_data', 'cpt_properties_save_meta_box_data_nonce' );
		$value = '';
		$company = get_post_meta( $post->ID , 'cpt_properties_company', true );
		$location = get_post_meta( $post->ID , 'cpt_properties_address', true );
		$email = get_post_meta( $post->ID , 'cpt_properties_email', true );
		$website = get_post_meta( $post->ID , 'cpt_properties_website', true );
		$amenities = get_post_meta( $post->ID, 'cpt_properties_amenities', true );
		$rooms = get_post_meta( $post->ID, 'cpt_properties_rooms', true );
		$rents = get_post_meta( $post->ID, 'cpt_properties_rents', true );
		$ratings = get_post_meta( $post->ID, 'cpt_properties_ratings', true );
		$vendors = $this->get_vendors_list();

		echo '<table cellspacing="10" cellpadding="10" border="0">';
		
		// Company name 
		echo '<tr>';
		echo '<td>';
			echo '<label for="cpt_properties_company">';
			_e( 'Company', 'off-campus-apply-properties' );
			echo '</label> ';
		echo '</td>';
		echo '<td>';
			echo '<select style="width:100%;" id="cpt_properties_company" name="cpt_properties_company">';
				foreach ( $vendors as $key => $vendor ) {
					if ( $vendor->ID == $company )
						echo '<option selected="selected" value="' . esc_attr( $vendor->ID ) . '">' . esc_attr( $vendor->display_name ) . '</option>';
					else
						echo '<option value="' . esc_attr( $vendor->ID ) . '">' . esc_attr( $vendor->display_name ) . '</option>';

				}
			echo '</select>';
		echo '</td>';
		echo '</tr>';
		
		// Location / Address 
		echo '<tr>';
		echo '<td>';
			echo '<label for="cpt_properties_address">';
			_e( 'Location', 'off-campus-apply-properties' );
			echo '</label> ';
		echo '</td>';
		echo '<td>';
			echo '<input type="text" id="cpt_properties_address" name="cpt_properties_address" value="' . esc_attr( $location ) . '" size="100" /><br />';
		echo '</td>';
		echo '</tr>';

		// Email address 
		echo '<tr>';
		echo '<td>';
			echo '<label for="cpt_properties_email">';
			_e( 'Email', 'off-campus-apply-properties' );
			echo '</label> ';
		echo '</td>';
		echo '<td>';
			echo '<input type="email" id="cpt_properties_email" name="cpt_properties_email" value="' . esc_attr( $email ) . '" size="100" /><br />';
		echo '</td>';
		echo '</tr>';

		// Website 
		echo '<tr>';
		echo '<td>';
			echo '<label for="cpt_properties_website">';
			_e( 'Website', 'off-campus-apply-properties' );
			echo '</label> ';
		echo '</td>';
		echo '<td>';
			echo '<input type="text" id="cpt_properties_website" name="cpt_properties_website" value="' . esc_attr( $website ) . '" size="100" /><br />';
		echo '</td>';
		echo '</tr>';

		// Amenities
		echo '<tr>';
		echo '<td>';
			echo '<label for="cpt_properties_amenities">';
			_e( 'Amenities', 'off-campus-apply-properties' );
			echo '</label> ';
		echo '</td>';
		echo '<td>';
			$amenities_unselected = null;
			$amenities_list = array( 
					'Furniture', 
					'All Utilities', 
					'Washer/Dryer', 
					'Off-Street Parking', 
					'Snow Removal', 
					'Pet-Friendly',
					'Gymnasium',
					'Swimming Pool'
				);
			if ( ! isset( $amenities ) || $amenities == null ) {
				$amenities = array( 
					__( 'Furniture', 'off-campus-apply-properties' ),
					__( 'All Utilities', 'off-campus-apply-properties' ), 
					__( 'Washer/Dryer', 'off-campus-apply-properties' ),
					__( 'Off-Street Parking', 'off-campus-apply-properties' ), 
					__( 'Snow Removal', 'off-campus-apply-properties' ),
					__( 'Pet-Friendly', 'off-campus-apply-properties' ),
					__( 'Gymnaisum', 'off-campus-apply-properties' ), 
					__( 'Swimming Pool', 'off-campus-apply-properties' ),
				);
			} else {
				if ( $amenities != null )
					$amenities_unselected = array_diff( $amenities_list, $amenities );
			}

			echo '<select style="width:100%;" id="cpt_properties_amenities" name="cpt_properties_amenities[]" multiple="multiple">';
				// selected
				foreach ( $amenities as $key => $value ) {
					echo '<option selected="selected" value="' . esc_attr( $value ) . '">' . esc_attr( $value ) . '</option>';
				}
				// unselected
				if ( isset( $amenities_unselected ) ) {
					foreach ( $amenities_unselected as $key => $value ) {
						echo '<option value="' . esc_attr( $value ) . '">' . esc_attr( $value ) . '</option>';
					}
				}
			echo '</select>';
		echo '</td>';
		echo '</tr>';

		// Rooms and Rent
		echo '<tr>';
		echo '<td>';
			echo '<label for="cpt_properties_rooms">';
			_e( 'Rooms/Rent', 'off-campus-apply-properties' );
			echo '</label> ';
		echo '</td>';
		echo '<td>';
			if ( ! isset( $rooms ) || $rooms == null )
				$rooms = array( 1,2,3,4,5,6,7,8 );
			if ( ! isset( $rents ) || $rents == null )
				$rents = array( 0, 0, 0, 0, 0, 0, 0, 0 );
			$count = count( $rooms ); 
			for( $i = 0; $i < $count; $i++ ){
				echo '<div class="cpt_properties_rooms_div">';
				if ( $rooms[ $i ] < 2 ) 
					echo '<span>' . $rooms[ $i ] .'-'. __( 'Bedroom', 'off-campus-apply-properties' ) . '</span>';
				else
					echo '<span>' . $rooms[ $i ] .'-'. __( 'Bedrooms', 'off-campus-apply-properties' ) . '</span>';
				echo '<input type="text" size="7" data-id="' . $rooms[ $i ] . '" 
							name="cpt_properties_rents[]" class="cpt_properties_rents" value="' . esc_attr( $rents[ $i ] ) . '" /> $';
				echo '<input type="hidden" name="cpt_properties_rooms[]" value="' . $rooms[ $i ] . '"  />';
				echo '</div>';
			}
		echo '</td>';
		echo '</tr>';

		// Ratings 
		echo '<tr>';
		echo '<td>';
			echo '<label for="cpt_properties_ratings">';
			_e( 'Ratings', 'off-campus-apply-properties' );
			echo '</label> ';
		echo '</td>';
		echo '<td>';
			echo '<input type="number" min="0" max="5" id="cpt_properties_ratings" name="cpt_properties_ratings" value="' . esc_attr( $ratings ) . '" size="5" /><br />';
		echo '</td>';
		echo '</tr>';

		echo '</table>';
	}

	public function save_cpt_properties_fields( $post_id, $post ) {

		if ( ! isset( $_POST['cpt_properties_save_meta_box_data_nonce'] ) ) {
			return;
		}

		if ( ! wp_verify_nonce( $_POST['cpt_properties_save_meta_box_data_nonce'], 'cpt_properties_save_meta_box_data' ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		 // Check the user's permissions.
	 	if ( isset( $_POST['post_type'] ) && 'properties' == $_POST['post_type'] ) {
		    if ( ! current_user_can( 'edit_page', $post_id ) ) {
		        return;
		    }
	 	} else {
		    if ( ! current_user_can( 'edit_post', $post_id ) ) {
		        return;
		    }
	 	}

 		$company = sanitize_text_field(  $_POST['cpt_properties_company'] );
 		$location = sanitize_text_field(  $_POST['cpt_properties_address'] );
 		$email = sanitize_text_field(  $_POST['cpt_properties_email'] );
 		$website = sanitize_text_field(  $_POST['cpt_properties_website'] );
		$amenities = $_POST['cpt_properties_amenities'];
		$rooms = $_POST['cpt_properties_rooms'];
		$rents = $_POST['cpt_properties_rents'];
		$ratings = $_POST['cpt_properties_ratings'];
		
		update_post_meta( $post_id, 'cpt_properties_company', $company );
		update_post_meta( $post_id, 'cpt_properties_address', $location );
		update_post_meta( $post_id, 'cpt_properties_email', $email );
		update_post_meta( $post_id, 'cpt_properties_website', $website );
		update_post_meta( $post_id, 'cpt_properties_amenities', $amenities );
		update_post_meta( $post_id, 'cpt_properties_rooms', $rooms );
		update_post_meta( $post_id, 'cpt_properties_rents', $rents );
		update_post_meta( $post_id, 'cpt_properties_ratings', $ratings );

		// added special key for comparing query
		update_post_meta( $post_id, 'cpt_properties_rents_string', implode('-', $rents ) );
	}

	public function get_vendors_list() {
		$args = array(
    		'role'    => 'vendor',
    		'orderby' => 'user_nicename',
    		'order'   => 'ASC'
		);
		$users = get_users( $args );
		return $users;
	}
}
