(function( $ ) {
	'use strict';
	
	$( document ).ready( function() {
    	$('#cpt_properties_amenities').select2({
    		placeholder: 'Select Amenities',
    		allowClear: true,
		    width: 'resolve' // need to override the changed default
    	});

    	$('#cpt_properties_company').select2({
    		placeholder: 'Select Company',
    		allowClear: true,
		    width: 'resolve' // need to override the changed default
    	});
    	
		var $searchfield = $('#cpt_properties_amenities').parent().find('.select2-search__field');
		$searchfield.css('display', 'none');
		$searchfield.prop('disabled', true);

    	// $('#cpt_properties_amenities').on('select2:opening select2:closing', function( event ) {
		// });
	});

})( jQuery );
